
from flask import Flask, render_template, request, redirect, session
from config import SECRET_KEY
from services.auth import login, register
from services.media import list_media

app = Flask(__name__)
app.secret_key = SECRET_KEY

@app.route("/")
def index():
    media = list_media()
    return render_template("index.html", media=media)

@app.route("/login", methods=["GET","POST"])
def login_view():
    if request.method == "POST":
        user = login(request.form["username"], request.form["password"])
        if user:
            session["user_id"] = user["id"]
            return redirect("/")
    return render_template("login.html")

@app.route("/register", methods=["GET","POST"])
def register_view():
    if request.method == "POST":
        register(request.form["username"], request.form["password"], request.form["role"])
        return redirect("/login")
    return render_template("register.html")

if __name__ == "__main__":
    app.run(debug=True)
