
from werkzeug.security import generate_password_hash, check_password_hash
from models.base import query, execute

def register(username, password, role="user"):
    pw = generate_password_hash(password)
    return execute("INSERT INTO users(username,password,role) VALUES (?,?,?)",
                   [username, pw, role])

def login(username, password):
    user = query("SELECT * FROM users WHERE username=?", [username], one=True)
    if user and check_password_hash(user["password"], password):
        return user
    return None
