
from models.base import query
from models.media import factory

def list_media():
    rows = query("SELECT * FROM media")
    return [factory(r) for r in rows]
