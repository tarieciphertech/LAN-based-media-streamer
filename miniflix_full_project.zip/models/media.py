
from pathlib import Path
from config import VIDEO_EXT

class Media:
    def __init__(self, row):
        self.id = row["id"]
        self.filepath = Path(row["filepath"])
        self.title = row["title"]
        self.category = row["category"]

    def is_video(self):
        return False

class VideoMedia(Media):
    def is_video(self):
        return True

def factory(row):
    if Path(row["filepath"]).suffix.lower() in VIDEO_EXT:
        return VideoMedia(row)
    return Media(row)
